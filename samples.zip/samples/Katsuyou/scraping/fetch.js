const url = "https://higpen.jellybean.jp/";
fetch(url)
  .then((resp) => resp.text())
  .then((text) => console.log(text));
