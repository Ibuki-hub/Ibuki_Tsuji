const url = "https://higpen.jellybean.jp/";
const { JSDOM } = require("jsdom");
const base = url.split("/").slice(0, 3).join("/");
const dir = url.split("/").slice(0, -1).join("/") + "/";
fetch(url)
  .then((resp) => resp.text())
  .then((text) => {
    const document = new JSDOM(text).window.document;
    const set = new Set();
    for (const a of document.getElementsByTagName("a")) {
      if (a.href.includes("://")) set.add(a.href);
      else if (a.href.startsWith("/")) set.add(base + a.href);
      else set.add(dir + a.href);
    }
    console.log(Array.from(set).sort().join("\n"));
  });
