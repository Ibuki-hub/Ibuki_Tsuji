const url = "https://higpen.jellybean.jp/";
const { JSDOM } = require("jsdom");
fetch(url)
  .then((resp) => resp.text())
  .then((text) => {
    const document = new JSDOM(text).window.document;
    for (const a of document.getElementsByTagName("a")) {
      console.log(a.href);
    }
  });
