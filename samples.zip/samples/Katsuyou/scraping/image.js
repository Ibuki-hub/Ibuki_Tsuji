const url = "https://higpen.jellybean.jp/";
const { JSDOM } = require("jsdom");
const { Buffer } = require("Buffer");
const fs = require("fs");
const base = url.split("/").slice(0, 3).join("/");
const dir = url.split("/").slice(0, -1).join("/") + "/";
fetch(url)
  .then((resp) => resp.text())
  .then((text) => {
    const document = new JSDOM(text).window.document;
    const set = new Set();
    for (const img of document.getElementsByTagName("img")) {
      if (img.src.includes("://")) set.add(img.src);
      else if (img.src.startsWith("/")) set.add(base + img.src);
      else set.add(dir + img.src);
    }
    let n = 0;
    for (const src of set) {
      fetch(src)
        .then((resp) => resp.blob())
        .then((blob) => blob.arrayBuffer())
        .then((buf) => {
          ext = "." + src.split(".").at(-1);
          file = "image" + n + ext;
          console.log(file + " <- " + src);
          fs.createWriteStream(file).write(Buffer.from(buf));
          n++;
        });
    }
  });
