window.addEventListener("load", () => {
  fetch("weather.json")
    .then((resp) => resp.text())
    .then((text) => {
      document.getElementById("weather").innerHTML = text;
    });
});
