function updateWeather() {
  fetch("weather.json?" + Date.now())
    .then((resp) => resp.json())
    .then((json) => {
      const table = document.getElementById("weatherTable");
      const tbody = table.getElementsByTagName("tbody")[0];
      tbody.innerHTML = "";
      const temp = document.getElementById("weatherTemplate");
      for (const info of json) {
        const tr = temp.content.cloneNode(true);
        for (const td of tr.querySelectorAll("td")) {
          td.textContent = info[td.textContent];
        }
        tbody.appendChild(tr);
      }
    });
}

window.addEventListener("load", () => {
  updateWeather();
  setInterval(updateWeather, 1000);
});
