window.addEventListener("load", () => {
  fetch("weather.json")
    .then((resp) => resp.json())
    .then((json) => {
      const table = document.getElementById("weatherTable");
      const tbody = table.getElementsByTagName("tbody")[0];
      const temp = document.getElementById("weatherTemplate");
      for (const info of json) {
        const tr = temp.content.cloneNode(true);
        for (const td of tr.querySelectorAll("td")) {
          td.textContent = info[td.textContent];
        }
        tbody.appendChild(tr);
      }
    });
});
