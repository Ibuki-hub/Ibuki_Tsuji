window.addEventListener("load", () => {
  fetch("weather.json")
    .then((resp) => resp.json())
    .then((json) => {
      const table = document.getElementById("weatherTable");
      const tbody = table.getElementsByTagName("tbody")[0];
      for (const info of json) {
        tbody.innerHTML +=
          "<tr>" +
          `<td>${info.city}</td>` +
          `<td>${info.weather}</td>` +
          `<td>${info.max}</td>` +
          `<td>${info.min}</td>` +
          `<td>${info.rain}</td>` +
          "</tr>";
      }
    });
});
